﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Product : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        //String strsql = String.Format("select * from merchandisc where MerName like '%{0}%'",txtKey.Text);
        //SqlDataSource1.SelectCommand = strsql;
        //GridView1.DataBind();
    }
}